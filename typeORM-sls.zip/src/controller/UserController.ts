import { Database } from "../connection/connection";
import User from '../entity/User'

export default class UserController {
  db: any
  constructor(){
    this.db = this.connect()
  }

  async connect (){
    const database = new Database()
    this.db = await database.getConnection()
  }

  create (data: any){
    return new Promise(async (resolve, reject) => {
      if(!this.db) {
        await this.connect()
      }
      let userRepository = this.db.getRepository(User);
      let user: any = userRepository.create()
      user.firstName = data.firstName,
      user.lastName = data.lastName,
      user.phoneNumber = data.phoneNumber

      await userRepository.save(user)
        .then(res => resolve(res))
        .catch(err => reject(err))
    })
  }

  get (filter: any){
    return new Promise(async (resolve, reject)=> {
      if(!this.db) {
        await this.connect()
      }
      let userRepository = this.db.getRepository(User);
      await userRepository.find(filter)
        .then(res => resolve(res))
        .catch(err => reject(err))
    })
  }
    

  update (filter: any, updates: any){
    return new Promise(async (resolve, reject)=> {
      if(!this.db) {
        await this.connect()
      }
      let userRepository = this.db.getRepository(User);
      await userRepository.update(filter, updates)
        .then(res => resolve(res))
        .catch(err => reject(err))
    })
  }

  remove (filter: any){
    return new Promise(async (resolve, reject)=> {
      if(!this.db) {
        await this.connect()
      }
      let userRepository = this.db.getRepository(User);
      await userRepository.remove(filter)
        .then(res => resolve(res))
        .catch(err => reject(err))
    })
  }
}