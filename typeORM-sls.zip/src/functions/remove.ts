import UserController from '../controller/UserController'
import { Context } from 'aws-lambda'

export default async (event: any, context: Context) => {
  try {
    const userId: string = (event.queryStringParameters) ? event.queryStringParameters.userId : false
    const phoneNumber: string = (event.queryStringParameters) ? event.queryStringParameters.phoneNumber : false

    if(!userId && !phoneNumber){
      return {
        statusCode: 422,
        body: JSON.stringify(
          {
            message: 'failed to remove user',
            error: 'filter parameter is missing'
          }
        )
      }
    }

    let filter: any = {}
    userId && (filter.userId = userId)
    phoneNumber && (filter.phoneNumber = userId)

    const userController = new UserController()
    const user = userController.remove(filter)

    return {
      statusCode: 200,
      body: JSON.stringify(
        {
          message: 'User removed successfully',
          data: user
        }
      ),
    }
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify(
        {
          message: 'failed to created user',
          error: err.message
        }
      )
    }
  }
}
