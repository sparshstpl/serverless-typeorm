import UserController from '../controller/UserController'
import { Context } from 'aws-lambda'

export default async (event: any, context: Context) => {
  try {
    const userId: string = (event.queryStringParameters) ? event.queryStringParameters.userId : false
    const phoneNumber: string = (event.queryStringParameters) ? event.queryStringParameters.phoneNumber : false

    if(!userId && !phoneNumber){
      return {
        statusCode: 422,
        body: JSON.stringify(
          {
            message: 'failed to update user',
            error: 'filter parameter is missing'
          }
        )
      }
    }
    let filter: any = {}
    userId && (filter.userId = userId)
    phoneNumber && (filter.phoneNumber = userId)

    const body = JSON.stringify(event.body)
    const userController = new UserController()
    const user = userController.update(1, {})

    return {
      statusCode: 200,
      body: JSON.stringify(
        {
          message: 'User updated successfully',
          data: user,
        }
      ),
    }
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify(
        {
          message: 'failed to update user',
          error: err.message
        }
      )
    }
  }
}
  